CREATE TRIGGER tr_CheckExpiredBarang
        ON tb_barang
        AFTER INSERT
        AS
    BEGIN
        DECLARE @Today DATE = GETDATE();

        SELECT
            i.kode_barang,
            i.nama_barang,
            i.expired_date
        FROM
            inserted i
        WHERE
            i.expired_date < @Today;
    END;
go


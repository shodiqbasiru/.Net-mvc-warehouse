CREATE PROCEDURE sp_GetBarangGudang
    @PageNumber INT = 1,
    @PageSize INT = 10,
    @SortColumn VARCHAR(255) = 'nama_gudang',
    @SortOrder VARCHAR(4) = 'ASC'
AS
BEGIN
    DECLARE @SQL NVARCHAR(MAX);
    DECLARE @Offset INT = (@PageNumber - 1) * @PageSize;

    SET @SQL = N'SELECT 
                    g.nama_gudang, 
                    g.kode_gudang, 
                    b.nama_barang, 
                    b.harga_barang, 
                    b.expired_date
                FROM 
                    tb_gudang g
                INNER JOIN 
                    tb_barang b ON g.id = b.gudang_id
                ORDER BY ' + QUOTENAME(@SortColumn) + ' ' + @SortOrder + '
                OFFSET ' + CAST(@Offset AS NVARCHAR(10)) + ' ROWS
                FETCH NEXT ' + CAST(@PageSize AS NVARCHAR(10)) + ' ROWS ONLY;';

    EXEC sp_executesql @SQL;
END;
go

